#' AdpQMLE.
#'
#' @name AdpQMLE
#' @docType package
NULL
